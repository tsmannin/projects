from pathlib import Path
import nba
import nba_url_builder as s

def nba_options():
    print("1. Conference")
    print("2. Team")
    print("3. Player")
    print("4. Quit")
    choice = int(input())
    return choice


def process_stats(choice):
    if choice == 1:
        #print conference stats here
        conf = input("Enter conference name: (East/West)")
        s.scrape_conference(conf)
    elif choice == 2:
        #print team stats here
        team = input("Enter team name: ")
        url = s.build_team_url(team)
        s.scrape_team(url)
    elif choice == 3:
        #print player stats here
        player = input("Enter player name: (first name) (last name)")
        s.scrape_player(player)

    elif choice == 4:
        pass

def process_csv_creation(choice):
    if choice == 1:
        #create csv file for conference
        conf = input("Enter conference name: (East/West)")
        myConf = nba.Conference(conf, s.scrape_conference(conf))
    elif choice == 2:
        #create csv file for team
        team = input("Enter team name: ")
        url = s.build_team_url(team)
        myTeam = nba.Team(team, s.scrape_team(url))
    elif choice == 3:
        #create csv file for player
        player = input("Enter player name: (first name) (last name)")
        myPlayer = nba.Player(s.scrape_player(player))
        myPlayer.create_player_csv()
    elif choice == 4:
        pass

def store_file():
    savedir = Path(input("Enter the directory you want to save in."))
    if not savedir.exists():
        savedir.mkdir()
    file_name = input("What is the name of the file you want to store? (include the extension)")
    #file_name = savedir + Path(file_name)
    print("Where would you like to store the file?")
    choice = nba_options()
    if choice == 1:
        conference_path = savedir / Path("Conferences")
        if not conference_path.exists():
            conference_path.mkdir()
        file = list(savedir.glob(file_name))
        move_to = conference_path / Path(file_name)
    elif choice == 2:
        team_path = savedir / Path("Teams")
        if not team_path.exists():
            team_path.mkdir()
        file = list(savedir.glob(file_name))
        move_to = team_path / Path(file_name)
    elif choice == 3:
        player_path = savedir / Path("Players")
        if not conference_path.exists():
            team_path.mkdir()
        file = list(savedir.glob(file_name))
        move_to = team_path / Path(file_name)
    elif choice == 4:
        pass





def main():
    print("Hi. Welcome to our NBA stats filing system. What would you like to do?")
    print("1. Get stats")
    print("2. Create csv files")
    print("3. Sort Files")
    print("4. Quit")
    choice = int(input())
    if choice == 1:
        print("What kind of stats would you like?")
        choice = nba_options()
        process_stats(choice)
    elif choice == 2:
        print("What kind of csv file do you want to create?")
        choice = nba_options()
        process_csv_creation(choice)
    elif choice == 3:
        #we need to find out what we want to update
        store_file()
    elif choice == 4:
        pass



if __name__ == "__main__":
    main()